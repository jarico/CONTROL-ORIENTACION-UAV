/*
* Generated S-function Target for model UAV. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Sat Dec 11 19:24:53 2021
*/

#ifndef RTWSFCN_UAV_sf_H
#define RTWSFCN_UAV_sf_H

#include "UAV_sfcn_rtw/UAV_sf.h"
  #include "UAV_sfcn_rtw/UAV_sf_private.h"

#endif
