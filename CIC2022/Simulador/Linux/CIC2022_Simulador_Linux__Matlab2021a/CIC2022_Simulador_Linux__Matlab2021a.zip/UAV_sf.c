/*
 * Generated S-function Target for model UAV. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Sat Dec 11 19:10:55 2021
 */

#include "UAV_sf.h"
#include "UAV_sfcn_rtw/UAV_sf.c"
#include "UAV_sfcn_rtw/UAV_sf_data.c"


